#!/bin/bash
#
# Copyright © 2018-2021 Inria.  All rights reserved.
# $COPYRIGHT$
#

./contrib/windows/check-versions.sh --quiet
./contrib/android/check-versions.sh --quiet
./contrib/windows-cmake/check-versions.sh --quiet
